'use strict';
const fetch = require('node-fetch');	//npm install node-fetch

module.exports.hello = async (event) => {
const jsonEvent = JSON.parse(event.body);
console.log(jsonEvent);
//url lampada Trope
// https://vnsfy51o29.execute-api.us-east-1.amazonaws.com/
if (jsonEvent.review.state == 'changes_requested') {
  console.log('Algum Miseravi precisa ajustar o PR...');
  await fetch('https://vnsfy51o29.execute-api.us-east-1.amazonaws.com/red');

  // if (response.ok) {
  // }
} else {
  await fetch('https://vnsfy51o29.execute-api.us-east-1.amazonaws.com/blue');
  console.log('Alteraram o repositório fique de olho seu lascado!');
}

return true;
  // return {
  //   statusCode: 200,
  //   body: JSON.stringify(
  //     {
  //       message: 'Go Serverless v1.0! Your function executed successfully!',
  //       input: event,
  //     },
  //     null,
  //     2
  //   ),
  // };

  // Use this code if you don't use the http event with the LAMBDA-PROXY integration
  // return { message: 'Go Serverless v1.0! Your function executed successfully!', event };
};
